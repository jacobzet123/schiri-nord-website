Dieses Paket enthält eine mehrseitige, professionelle Website für die Schiedsrichtergruppe Nord.
Inhalte wurden aus öffentlich verfügbaren Informationen übernommen (Trainingszeiten, Regeldiskussionen, Kontakt).
Bitte prüfe das Impressum und rechtliche Angaben vor Live-Schaltung.

Dateistruktur:
- index.html
- ueber-uns.html
- training.html
- regeldiskussion.html
- termine.html
- veranstaltungen.html
- kontakt.html
- style.css
- script.js
- assets/logo.svg

Bereit zum Upload: entpacke das ZIP und lade den Ordner auf deinen Webserver.
